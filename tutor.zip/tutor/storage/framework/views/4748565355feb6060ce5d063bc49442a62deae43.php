

<?php $__env->startSection('content'); ?>

        <section class="inner-banner">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active"><a href="#">About</a></li>
                </ul><!-- /.list-unstyled -->
                <h2 class="inner-banner__title">About</h2><!-- /.inner-banner__title -->
            </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="about-one about-one__about-page">
            <img src="assets/images/circle-stripe.png" class="about-one__circle" alt="">
            <div class="container text-center">
                <div class="block-title text-center">
                    <h2 class="block-title__title">Let’s do study with <br>
                        expert teachers</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="about-one__img">
                    <div class="row">
                        <div class="col-lg-6">
                            <img src="assets/images/about01.jpg" alt="">
                        </div><!-- /.col-lg-6 -->
                        <div class="col-lg-6">
                            <img src="assets/images/about02.jpg" alt="">
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.row -->
                    <div class="about-one__review">
                        <p class="about-one__review-count counter">88750</p><!-- /.about-one__review-count -->
                        <div class="about-one__review-stars">
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                        </div><!-- /.about-one__stars -->
                        <p class="about-one__review-text">students loved us </p><!-- /.about-one__review-text -->
                    </div><!-- /.about-one__review -->
                </div><!-- /.about-one__img -->
                <p class="about-one__text">There are many variations of passages of lorem ipsum available, but the majority have
                    <br>
                    suffered alteration in some form, by injected humour words which don't look even slightly <br> believable.
                    Lorem
                    Ipsn gravida nibh vel velit auctor aliquetn auci elit cons.</p><!-- /.about-one__text -->
                <a href="#" class="thm-btn about-one__btn">Start Learning Now</a><!-- /.thm-btn -->
            </div><!-- /.container -->
        </section><!-- /.about-one about-one__about-page -->
        <section class="team-one  ">
            <div class="container">
                <div class="block-title text-center">
                    <h2 class="block-title__title">Meet the best <br>
                        teachers</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="row">
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="assets/images/team-1-1.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name"><a href="team-details.html">Adelaide Hunter</a></h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                                <p class="team-one__text">There are many varia of passages of lorem.</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-facebook-square"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div><!-- /.team-one__social -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="assets/images/team-1-2.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name"><a href="team-details.html">Christina Newman</a></h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                                <p class="team-one__text">There are many varia of passages of lorem.</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-facebook-square"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div><!-- /.team-one__social -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="assets/images/team-1-3.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name"><a href="team-details.html">Gilbert Daniels</a></h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                                <p class="team-one__text">There are many varia of passages of lorem.</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-facebook-square"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div><!-- /.team-one__social -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="assets/images/team-1-4.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name"><a href="team-details.html">Austin Caldwell</a></h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                                <p class="team-one__text">There are many varia of passages of lorem.</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-facebook-square"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div><!-- /.team-one__social -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.team-one team-page -->
        <section class="video-one">
            <div class="container">
                <img src="assets/images/scratch-1-1.png" class="video-one__scratch" alt="">
                <div class="row">
                    <div class="col-lg-6 d-flex align-items-end">
                        <div class="video-one__content">
                            <h2 class="video-one__title">Take a tour dolor <br>
                                sit amet, consect <br>
                                etur elit</h2><!-- /.video-one__title -->
                            <a href="#" class="thm-btn video-one__btn">Learn More</a><!-- /.thm-btn -->
                        </div><!-- /.video-one__content -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="video-one__img">
                            <img src="assets/images/video-1-1.jpg" alt="">
                            <a href="#" class="video-one__popup"><i class="fas fa-play"></i><!-- /.fas fa-play --></a>
                        </div><!-- /.video-one__img -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.video-one -->
        <section class="brand-one  ">
            <div class="container">
                <div class="brand-one__carousel owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="assets/images/brand-1-1.png" alt="">
                    </div><!-- /.item -->
                </div><!-- /.brand-one__carousel owl-carousel owl-theme -->
            </div><!-- /.container -->
        </section><!-- /.brand-one -->
        <section class="testimonials-one  ">
            <div class="container">
                <div class="block-title text-center">
                    <h2 class="block-title__title">What our students <br>
                        have to say</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="testimonials-one__carousel owl-carousel owl-theme">
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-1.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Anne Hall</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-2.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Andre Obrien</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form, by injected humour.</p>
                            <!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-3.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Shane Vasquez</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-4.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Maud Lee</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-5.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Barbara Kennedy</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form, by injected humour.</p>
                            <!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-6.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Duane Carter</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-1.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Sally Green</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-2.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Iva Santos</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                                the majority have suffered alteration in some form, by injected humour.</p>
                            <!-- /.testimonials-one__text -->
                            <img src="assets/images/team-1-3.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Max Burns</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                </div><!-- /.testimonials-one__carousel owl-carousel owl-theme -->
            </div><!-- /.container -->
        </section><!-- /.testimonials-one -->
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bg_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saiflaravel\tutor\resources\views/front/about.blade.php ENDPATH**/ ?>