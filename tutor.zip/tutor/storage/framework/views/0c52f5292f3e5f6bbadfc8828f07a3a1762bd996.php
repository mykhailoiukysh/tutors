<?php echo $__env->make('inc.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <!-- Side Navbar -->
        <?php echo $__env->make('inc.admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Side Navbar -->

        <div class="content-inner"> 
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Dashboard</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
            <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
              
                <!-- Form Elements -->
                <div class="col-lg-12">
                  <div class="card">
                   
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Theme Options</h3>
                    </div>
                    <div class="card-body">

                       <p class="mssg text-success"><?php echo e(session('mssg')); ?></p>
                         
                      <form class="form-horizontal" action="/Admin/theme-options" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Logo</label>
                          <div class="col-sm-9">
                            <input type="file" name="logo" class=""> <img src="<?php echo e(asset('assets/images/' )); ?>/<?php echo e($general->logo); ?>" height="50" >
                            <input type="hidden" name="oldlogo" value="<?php echo e($general->logo); ?>">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Top Header Background</label>
                          <div class="col-sm-9">
                            <input type="color" name="top_header" value="<?php echo e($general->top_header); ?>" class=" "> 
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Email</label>
                          <div class="col-sm-9">
                            <input type="text" name="email" value="<?php echo e($general->email); ?>" class="form-control">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Phone</label>
                          <div class="col-sm-9">
                            <input type="text" name="phone" value="<?php echo e($general->phone); ?>" class="form-control">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Menu Color</label>
                          <div class="col-sm-9">
                            <input type="color" name="menu_color" value="<?php echo e($general->menu_color); ?>" class=" ">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Footer Background</label>
                          <div class="col-sm-9">
                            <input type="text" name="footer_bg" value="<?php echo e($general->footer_bg); ?>" class="form-control">
                          </div>
                        </div>
                       
                        <div class="line"></div>
                        <div class="form-group row">
                          <div class="col-sm-4 offset-sm-3">                            
                            <!-- <button type="submit" class="btn btn-primary">Save changes</button> -->
                            <input type="submit" name="" value="Save changes">
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>


  <?php echo $__env->make('inc.admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saiflaravel\tutor\resources\views/admin/general.blade.php ENDPATH**/ ?>