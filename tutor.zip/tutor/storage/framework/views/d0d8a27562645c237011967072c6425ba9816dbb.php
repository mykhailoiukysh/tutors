

<?php $__env->startSection('content'); ?>
 <section class="inner-banner">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active"><a href="#">How to works</a></li>
                </ul><!-- /.list-unstyled -->
                <h2 class="inner-banner__title">How to Works</h2><!-- /.inner-banner__title -->
            </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="faq-one">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fas fa-sign-in-alt"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Signing up and start the application</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fas fa-chalkboard"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Start Tutoring</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fab fa-leanpub"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Complete a Subject Exam</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fas fa-chalkboard-teacher"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Training/Mock Session</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fas fa-money-check-alt"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Get paid</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span><i class="fas fa-school"></i></span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                                    subscription at any time from within your
                                    dashboard.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.faq-one -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bg_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saiflaravel\tutor\resources\views/front/howitwork.blade.php ENDPATH**/ ?>