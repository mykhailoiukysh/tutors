<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class tutors extends Controller
{
    
    


}
