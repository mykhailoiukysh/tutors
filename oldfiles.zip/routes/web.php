<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/************************
 Admin Route Option 
*************************/

Route::get('/Admin', function () {
    return view('admin.index');
});
Route::get('/Admin/theme-options', 'AdminController@theme_options');




/************************
 Fontend Route Option 
*************************/
Route::get('/', function () {
    return view('front.welcome');
});

Route::get('/about', function () {
    return view('front.about');
});

Route::get('/howitworks', function () {
    return view('front.howitwork');
});

Route::get('/tutors', function () {
    return view('front.tutors');
});

Route::get('/fee', function () {
    return view('front.fee');
});

Route::get('/contact', function () {
    return view('front.contact');
});

