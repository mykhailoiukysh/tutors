<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class general extends Model
{
    //
}
