<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\General;


class AdminController extends Controller
{
    //
    
    public function theme_options($value='')
    {
    	//$general = General::where('id', 1)->->find(1);
    	$general = General::find(1);

	     return view('admin.general', ['general' => $general] );
    }

}
